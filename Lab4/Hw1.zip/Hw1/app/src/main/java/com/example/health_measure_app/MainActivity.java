package com.example.health_measure_app;


import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Chronometer chronometer;
    private boolean isTimerRunning;
    private long lastPauseOffset;
    private TextView tvHeartRate, tvDistance;
    private Button btnStart, btnPause, btnEnd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views from the layout
        chronometer = findViewById(R.id.tvTimer);
        tvHeartRate = findViewById(R.id.tvHeartRate);
        tvDistance = findViewById(R.id.tvDistance);
        btnStart = findViewById(R.id.btnStart);
        btnPause = findViewById(R.id.btnPause);
        btnEnd = findViewById(R.id.btnEnd);

        // Setup the chronometer
        chronometer.setFormat("Time: %s");

        // Start Button
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isTimerRunning) {
                    chronometer.setBase(SystemClock.elapsedRealtime() - lastPauseOffset);
                    chronometer.start();
                    isTimerRunning = true;
                }
            }
        });

        // Pause Button
        btnPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isTimerRunning) {
                    chronometer.stop();
                    lastPauseOffset = SystemClock.elapsedRealtime() - chronometer.getBase();
                    isTimerRunning = false;
                }
            }
        });

        // End Button
        btnEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chronometer.stop();
                chronometer.setBase(SystemClock.elapsedRealtime());
                lastPauseOffset = 0;
                isTimerRunning = false;
            }
        });

        // Placeholder for heart rate and distance setup
        // You would need to set up sensor listeners or APIs to update these values
        tvHeartRate.setText("Heart Rate: -- bpm");
        tvDistance.setText("Distance: -- meters");
    }
}
