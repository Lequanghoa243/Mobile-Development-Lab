package com.example.myapplication;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etWordInput;
    private Button btnSearch;
    private TextView tvResult;
    private DictionaryDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etWordInput = findViewById(R.id.etWordInput);
        btnSearch = findViewById(R.id.btnSearch);
        tvResult = findViewById(R.id.tvResult);
        dbHelper = new DictionaryDatabaseHelper(this);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String word = etWordInput.getText().toString().trim();
                searchWord(word);
            }
        });


        dbHelper.addWord("Hello", "Greeting to someone");
        dbHelper.addWord("Bee Bee", "Kieu Xuan Dieu Huong");
    }

    private void searchWord(String word) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        // Query for the exact word
        Cursor cursor = db.rawQuery("SELECT definition FROM dictionary WHERE word = ?", new String[]{word});

        // Check if the cursor is not empty and has the required column
        if (cursor.moveToFirst() && cursor.getColumnIndex("definition") != -1) {
            String definition = cursor.getString(cursor.getColumnIndex("definition"));
            tvResult.setText(definition);
        } else {
            // Close the previous cursor to avoid memory leaks
            cursor.close();

            // Query for similar words
            cursor = db.rawQuery("SELECT word FROM dictionary WHERE word LIKE ?", new String[]{"%" + word + "%"});
            StringBuilder similarWords = new StringBuilder();
            int columnIndex = cursor.getColumnIndex("word");

            if (columnIndex != -1) {
                while (cursor.moveToNext()) {
                    similarWords.append(cursor.getString(columnIndex)).append("\n");
                }
            }

            if (similarWords.length() > 0) {
                tvResult.setText("Did you mean?\n" + similarWords.toString());
            } else {
                tvResult.setText("No results found.");
            }
        }
        cursor.close();
    }

}
